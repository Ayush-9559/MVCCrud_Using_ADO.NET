﻿namespace CRUDAppUsingADO
{
    public static class ConnectionString
    {
        private static string cs = "Data Source=DESKTOP-N6G8OPO\\SQLSERVER;Initial Catalog=SAMPLE;Integrated Security=True;Encrypt=False";
        public static string dbcs { get => cs; }
    }
}
