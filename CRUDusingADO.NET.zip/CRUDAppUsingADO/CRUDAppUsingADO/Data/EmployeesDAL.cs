﻿using CRUDAppUsingADO.Models;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography.Pkcs;

namespace CRUDAppUsingADO.Data
{
    public class EmployeesDAL
    {
        string cs = ConnectionString.dbcs;


        // Fetching All Employees //
        public List<Employees> GetAllEmployees()
        {
            List<Employees> emp = new List<Employees>();
            using (SqlConnection connection = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("GetallEmp", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Employees employee = new Employees();
                    employee.Id = Convert.ToInt32(reader["Id"]);
                    employee.Name = reader["Name"].ToString()??"";
                    employee.Gender = reader["Gender"].ToString() ?? "";
                    employee.Age = Convert.ToInt32(reader["Age"]);
                    employee.Salary = Convert.ToInt32(reader["Salary"]);
                    employee.City = reader["City"].ToString() ?? "";
                    emp.Add(employee);
                }
                return emp;
            }
        }


        // Adding New Employees //
        public void AddEmployee(Employees emp)
        {
            using(SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("AddEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@gender", emp.Gender);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@salary", emp.Salary);
                cmd.Parameters.AddWithValue("@city", emp.City);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }


        // Edit Employees Details //
        public Employees GetEmployees(int? id)
        {
            Employees emp = new Employees();
            using(SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from emp_tbl where id = @id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    emp.Id = Convert.ToInt32(reader["Id"]);
                    emp.Name = reader["Name"].ToString() ?? "";
                    emp.Gender = reader["Gender"].ToString() ?? "";
                    emp.Age = Convert.ToInt32(reader["Age"]);
                    emp.Salary = Convert.ToInt32(reader["Salary"]);
                    emp.City = reader["City"].ToString() ?? "";
                }
            }
            return emp;
        }



        // Update Employees Details //
        public void UpdateEmployees(Employees emp)
        {
            using(SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("UpdateEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", emp.Id);
                cmd.Parameters.AddWithValue("@name", emp.Name);
                cmd.Parameters.AddWithValue("@gender", emp.Gender);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@salary", emp.Salary);
                cmd.Parameters.AddWithValue("@city", emp.City);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }


        // Delete Employees By Id //
        public void DeleteEmployees(int? id)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("DeleteEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
