create table emp_tbl 
(
Id int identity primary key, 
[Name] varchar(100) not null, 
Gender Varchar(50) not null,
Age int,
Salary decimal(8,2) not null,
City Varchar(100)
);

Select * from emp_tbl;

insert into emp_tbl ([Name], Gender, Age, Salary, City)
values
('Nikita', 'Female', 23, 18000, 'Thane'),
('Mithilesh', 'Male', 24, 18500, 'Thane'),
('Anjali', 'Female', 25, 15000, 'Satara'),
('Shilpa', 'Female', 23, 18000, 'Thane'),
('Ayush', 'Male', 23, 80000, 'Mumbai'),
('Nitesh', 'Male', 21, 70000, 'Mumbai');



/* Add Stored Procedure */
Go
Create Procedure AddEmp
@id int,
@name varchar(50),
@gender varchar(50),
@age int,
@salary decimal(8,2),
@city varchar(100)
as
begin 
	insert into emp_tbl (Id,[Name],Gender,Age,Salary,City) values
						(@id, @name, @gender, @age, @salary, @city);
end 



/* Update Stored Procedure */
Go
create procedure UpdateEmp
@id int,
@name varchar(50),
@gender varchar(50),
@age int,
@salary decimal(8,2),
@city varchar(100)
as
begin
	update emp_tbl set [Name]=@name, Gender=@gender, Age=@age, Salary=@salary, City=@city
			where Id=@id;
end


/* Delete Stored Procedure */
Go
create procedure DeleteEmp
@id int
as
begin 
	delete from emp_tbl where Id=@id;
end


/* Get All Employees Stored Procedure */
Go
create procedure GetallEmp
as
begin
	Select * from emp_tbl order by Id ASC;
end

Drop procedure GetallEmp;